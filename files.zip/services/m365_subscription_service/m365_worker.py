import os
import logging
from redis import Redis
from rq import Worker, Queue, Connection
from .m365_client import run_delta_for_subscription

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("m365_worker")

REDIS_URL = os.getenv("REDIS_URL", "redis://redis:6379/0")

if __name__ == "__main__":
    redis_conn = Redis.from_url(REDIS_URL)
    with Connection(redis_conn):
        q = Queue("m365-delta", connection=redis_conn)
        logger.info("Starting M365 worker listening on 'm365-delta'")
        worker = Worker([q], connection=redis_conn)
        worker.work()