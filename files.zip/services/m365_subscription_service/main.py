import os
import logging
from fastapi import FastAPI, Request, HTTPException
from pydantic import BaseModel
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from .models import Base
from .m365_client import create_graph_subscription, delete_graph_subscription
from redis import Redis
from rq import Queue

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("m365_service")

DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./dev.db")
REDIS_URL = os.getenv("REDIS_URL", "redis://redis:6379/0")
engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {})
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base.metadata.create_all(bind=engine)

# RQ queue
redis_conn = Redis.from_url(REDIS_URL)
q = Queue("m365-delta", connection=redis_conn)

app = FastAPI(title="M365 Subscription Service")

class RegisterRequest(BaseModel):
    integration_id: int
    notification_url: str
    resource: str = "me/mailFolders('Inbox')/messages"

class UnregisterRequest(BaseModel):
    subscription_id: str

@app.post("/subscriptions/register")
def register_subscription(req: RegisterRequest):
    try:
        sub = create_graph_subscription(req.integration_id, req.notification_url, req.resource)
        return {"status": "ok", "subscription": sub}
    except Exception as e:
        logger.exception("Error registering subscription")
        raise HTTPException(status_code=400, detail=str(e))

@app.post("/subscriptions/unregister")
def unregister_subscription(req: UnregisterRequest):
    try:
        delete_graph_subscription(req.subscription_id)
        return {"status": "ok"}
    except Exception as e:
        logger.exception("Error unregistering")
        raise HTTPException(status_code=400, detail=str(e))

@app.post("/webhook/receive")
async def webhook_receive(request: Request):
    # Graph validationToken challenge
    q_params = dict(request.query_params)
    validation_token = q_params.get("validationToken")
    if validation_token:
        return validation_token

    try:
        payload = await request.json()
    except Exception:
        raise HTTPException(status_code=400, detail="invalid payload")

    if payload.get("value"):
        for notice in payload.get("value", []):
            sub_id = notice.get("subscriptionId")
            client_state = notice.get("clientState")
            logger.info("Received webhook notice for subscription %s clientState=%s", sub_id, client_state)
            # Optionally validate client_state against DB here
            # Enqueue a background delta job to run_ delta_for_subscription
            try:
                q.enqueue("m365_client.run_delta_for_subscription", sub_id)
            except Exception:
                logger.exception("Failed to enqueue delta job for subscription %s", sub_id)
        return {"status": "accepted"}
    return {"status": "ignored"}