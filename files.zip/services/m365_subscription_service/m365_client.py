# ... [existing imports remain]
from .token_store import encrypt_token, decrypt_token
# Replace saving of access/refresh tokens to DB with encrypted versions (when updating Integration)
# Example: when refreshing tokens, do:
# integ.access_token = encrypt_token(tok['access_token'])  # BEFORE saving to DB
# When using integ.access_token to call Graph, always decrypt:
# access_token = decrypt_token(integ.access_token)
#
# Minimal illustrative updates below (partial snippets to integrate into refresh_microsoft_token):

def refresh_microsoft_token(integration: Integration):
    try:
        if not integration.refresh_token:
            return integration
        # decrypt refresh token before use
        refresh_token_plain = decrypt_token(integration.refresh_token) or integration.refresh_token
        data = {
            "client_id": os.getenv("MICROSOFT_CLIENT_ID"),
            "client_secret": os.getenv("MICROSOFT_CLIENT_SECRET"),
            "refresh_token": refresh_token_plain,
            "grant_type": "refresh_token",
            "scope": "offline_access Mail.Read"
        }
        r = requests.post(TOKEN_REFRESH_ENDPOINT, data=data, timeout=15)
        r.raise_for_status()
        tok = r.json()
        # encrypt tokens before storing
        if tok.get("access_token"):
            integration.access_token = encrypt_token(tok.get("access_token"))
        if tok.get("refresh_token"):
            integration.refresh_token = encrypt_token(tok.get("refresh_token"))
        if tok.get("expires_in"):
            from datetime import datetime, timedelta
            integration.expires_at = int((datetime.utcnow() + timedelta(seconds=int(tok.get("expires_in")))).timestamp())
        return integration
    except Exception:
        logger.exception("Error refreshing token")
        raise

# Everywhere integration.access_token is read to call Graph, use decrypt_token(integration.access_token) to obtain plaintext for Authorization header.
# For example:
# headers = {"Authorization": f"Bearer {decrypt_token(integ.access_token)}"}