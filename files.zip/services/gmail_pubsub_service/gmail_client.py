import os
import logging
import io
import base64
from google.oauth2.credentials import Credentials
from googleapiclient.discovery import build
import requests
from datetime import datetime, timedelta
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from .models import Integration, Document
from .storage import upload_bytes

logger = logging.getLogger("gmail_client")

DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./dev.db")
engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {})
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

GOOGLE_TOKEN_ENDPOINT = "https://oauth2.googleapis.com/token"

def refresh_google_token(integration: Integration):
    # Exchange refresh_token for new access_token
    if not integration.refresh_token:
        return integration
    try:
        data = {
            "client_id": os.getenv("GOOGLE_CLIENT_ID"),
            "client_secret": os.getenv("GOOGLE_CLIENT_SECRET"),
            "refresh_token": integration.refresh_token,
            "grant_type": "refresh_token"
        }
        r = requests.post(GOOGLE_TOKEN_ENDPOINT, data=data, timeout=10)
        r.raise_for_status()
        tok = r.json()
        integration.access_token = tok.get("access_token")
        if tok.get("refresh_token"):
            integration.refresh_token = tok.get("refresh_token")
        if tok.get("expires_in"):
            integration.expires_at = int((datetime.utcnow() + timedelta(seconds=int(tok.get("expires_in")))).timestamp())
        return integration
    except Exception:
        logger.exception("Failed to refresh google token")
        raise

def build_service_from_integration(integration: Integration):
    # refresh token if needed
    try:
        if integration.expires_at and integration.expires_at - 60 < datetime.utcnow().timestamp():
            integration = refresh_google_token(integration)
            # persist new tokens
            db = SessionLocal()
            db_integ = db.query(Integration).get(integration.id)
            db_integ.access_token = integration.access_token
            db_integ.refresh_token = integration.refresh_token
            db_integ.expires_at = integration.expires_at
            db.add(db_integ); db.commit(); db.close()
    except Exception:
        logger.exception("Token refresh check failed (continuing)")

    creds = Credentials(
        token=integration.access_token,
        refresh_token=integration.refresh_token,
        client_id=os.getenv("GOOGLE_CLIENT_ID"),
        client_secret=os.getenv("GOOGLE_CLIENT_SECRET"),
        token_uri=GOOGLE_TOKEN_ENDPOINT,
        scopes=["https://www.googleapis.com/auth/gmail.readonly"]
    )
    service = build("gmail", "v1", credentials=creds, cache_discovery=False)
    return service

def process_history_for_integration(integration_id: int, history_id: str = None):
    """
    Uses Gmail History API to fetch recent changes starting at history_id (if provided).
    If history_id is None, will list recent messages by querying messages with has:attachment.
    Downloads attachments for messages and writes Document rows with s3_key referencing MinIO.
    """
    db = SessionLocal()
    try:
        integ = db.query(Integration).get(integration_id)
        if not integ:
            raise Exception("integration not found")
        service = build_service_from_integration(integ)

        message_ids = set()

        # If history_id is provided, attempt to use history.list
        if history_id:
            try:
                resp = service.users().history().list(userId="me", startHistoryId=history_id).execute()
                for h in resp.get("history", []):
                    for ma in h.get("messagesAdded", []):
                        message_ids.add(ma.get("message", {}).get("id"))
                    for mu in h.get("messagesDeleted", []):
                        # ignore deletions for ingestion
                        pass
            except Exception:
                logger.exception("history.list failed; falling back to search")
                history_id = None

        # fallback: list messages with attachments
        if not message_ids:
            msgs = service.users().messages().list(userId="me", q="has:attachment", maxResults=50).execute()
            for m in msgs.get("messages", []):
                message_ids.add(m.get("id"))

        logger.info("Found %s messages to check for attachments for integration %s", len(message_ids), integration_id)

        for msg_id in message_ids:
            try:
                msg = service.users().messages().get(userId="me", id=msg_id, format="full").execute()
                headers = {h["name"].lower(): h["value"] for h in msg.get("payload", {}).get("headers", [])}
                sender = headers.get("from")
                recipients = headers.get("to")
                # recursively find parts with attachments
                def walk_parts(part):
                    parts = []
                    if part.get("parts"):
                        for p in part.get("parts", []):
                            parts.extend(walk_parts(p))
                    else:
                        parts.append(part)
                    return parts

                parts = walk_parts(msg.get("payload", {}))
                for p in parts:
                    filename = p.get("filename")
                    body = p.get("body", {})
                    mimeType = p.get("mimeType")
                    if filename and body.get("attachmentId"):
                        att = service.users().messages().attachments().get(userId="me", messageId=msg_id, id=body["attachmentId"]).execute()
                        data = att.get("data")
                        file_bytes = base64.urlsafe_b64decode(data.encode("utf-8"))
                        stream = io.BytesIO(file_bytes)
                        s3_key = upload_bytes(stream, filename)
                        doc = Document(
                            tenant_id=str(integ.id),
                            original_filename=filename,
                            s3_key=s3_key,
                            content_type=mimeType,
                            size=len(file_bytes),
                            sender=sender,
                            recipients=recipients,
                            processing_status="pending"
                        )
                        db.add(doc)
                        db.commit()
                        logger.info("Saved doc %s for integration %s", filename, integration_id)
            except Exception:
                logger.exception("Error processing message %s for integration %s", msg_id, integration_id)
    finally:
        db.close()