import pytest
from services.gmail_pubsub_service.gmail_client import process_history_for_integration
from unittest.mock import patch

def test_process_history_invalid_integration(monkeypatch):
    # patch DB session to return None
    class DummySession:
        def __init__(self): pass
        def query(self, *a, **k): return self
        def get(self, *a, **k): return None
    monkeypatch.setattr("services.gmail_pubsub_service.gmail_client.SessionLocal", lambda: DummySession())
    with pytest.raises(Exception):
        process_history_for_integration(9999, None)