import os
import logging
from redis import Redis
from rq import Worker, Queue, Connection
from .gmail_client import process_history_for_integration

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("gmail_worker")

REDIS_URL = os.getenv("REDIS_URL", "redis://redis:6379/0")

if __name__ == "__main__":
    redis_conn = Redis.from_url(REDIS_URL)
    with Connection(redis_conn):
        q = Queue("gmail-history", connection=redis_conn)
        logger.info("Starting Gmail worker listening on 'gmail-history'")
        worker = Worker([q], connection=redis_conn)
        worker.work()