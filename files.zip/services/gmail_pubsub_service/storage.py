import os
import boto3
from botocore.client import Config
import uuid

MINIO_ENDPOINT = os.getenv("MINIO_ENDPOINT", "minio:9000")
MINIO_ACCESS_KEY = os.getenv("MINIO_ACCESS_KEY", "minioadmin")
MINIO_SECRET_KEY = os.getenv("MINIO_SECRET_KEY", "minioadmin")
MINIO_BUCKET = os.getenv("MINIO_BUCKET", "docflow-dev")
MINIO_REGION = os.getenv("MINIO_REGION", "us-east-1")
MINIO_S3SECURE = os.getenv("MINIO_S3SECURE", "False").lower() in ("1", "true", "yes")

s3 = boto3.client(
    "s3",
    endpoint_url=f"http://{MINIO_ENDPOINT}" if not MINIO_S3SECURE else f"https://{MINIO_ENDPOINT}",
    aws_access_key_id=MINIO_ACCESS_KEY,
    aws_secret_access_key=MINIO_SECRET_KEY,
    config=Config(signature_version="s3v4"),
    region_name=MINIO_REGION,
)

def ensure_bucket():
    try:
        s3.head_bucket(Bucket=MINIO_BUCKET)
    except Exception:
        s3.create_bucket(Bucket=MINIO_BUCKET)

def upload_bytes(bytes_io, filename):
    ensure_bucket()
    key = f"{uuid.uuid4().hex}_{filename}"
    try:
        bytes_io.seek(0)
    except Exception:
        pass
    s3.upload_fileobj(bytes_io, MINIO_BUCKET, key)
    return key