from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from sqlalchemy.orm import sessionmaker
from sqlalchemy import create_engine
from .models import Base, Integration
import os
from .gmail_client import process_history_for_integration, refresh_google_token

DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./dev.db")
engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {})
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
router = APIRouter(prefix="/admin", tags=["admin"])

@router.get("/integrations")
def list_integrations():
    db = SessionLocal()
    try:
        items = db.query(Integration).all()
        return [{"id": i.id, "account_email": i.account_email, "expires_at": i.expires_at} for i in items]
    finally:
        db.close()

@router.post("/integrations/{integration_id}/refresh-token")
def admin_refresh_google(integration_id: int):
    db = SessionLocal()
    try:
        integ = db.query(Integration).get(integration_id)
        if not integ:
            raise HTTPException(status_code=404, detail="integration not found")
        try:
            refreshed = refresh_google_token(integ)
            db.add(refreshed); db.commit()
            return {"status": "ok"}
        except Exception as e:
            raise HTTPException(status_code=500, detail=str(e))
    finally:
        db.close()