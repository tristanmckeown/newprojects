import os
import base64
import json
import logging
from fastapi import FastAPI, Request, HTTPException, Header
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from .models import Base, Integration
from .gmail_client import process_history_for_integration
from redis import Redis
from rq import Queue
from google.oauth2 import id_token
from google.auth.transport import requests as google_requests

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("gmail_pubsub")

DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./dev.db")
REDIS_URL = os.getenv("REDIS_URL", "redis://redis:6379/0")
BACKEND_URL = os.getenv("BACKEND_URL", "http://backend:8000")  # fallback if you want to call backend
engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {})
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base.metadata.create_all(bind=engine)

redis_conn = Redis.from_url(REDIS_URL)
q = Queue("gmail-history", connection=redis_conn)

app = FastAPI(title="Gmail Pub/Sub Subscriber")

# Optional: expected audience for OIDC token verification (configure in env)
PUBSUB_AUDIENCE = os.getenv("PUBSUB_AUDIENCE", "")  # set to your push subscription's OIDC client/audience if used

@app.post("/pubsub/push")
async def pubsub_push(request: Request, authorization: str = Header(None)):
    """
    Accepts Google Cloud Pub/Sub push messages for Gmail watch notifications.
    Verifies optional OIDC token in Authorization header (Bearer <token>) and then enqueues a job
    to process the history for matching Integration(s). If OIDC isn't provided, proceeds but logs a warning.
    """
    # Verify OIDC token if present
    if authorization and authorization.lower().startswith("bearer "):
        token = authorization.split(" ", 1)[1]
        try:
            # verify token using google library; this will fetch Google's certs
            request_adapter = google_requests.Request()
            idinfo = id_token.verify_oauth2_token(token, request_adapter, PUBSUB_AUDIENCE or None)
            # idinfo contains issuer/aud claims; you can check 'aud' or 'email' here
            logger.info("Pub/Sub push token verified: aud=%s iss=%s", idinfo.get("aud"), idinfo.get("iss"))
        except Exception:
            logger.exception("Pub/Sub push JWT verification failed")
            # For security, you may want to return 401 here in production
            raise HTTPException(status_code=401, detail="invalid push token")

    try:
        payload = await request.json()
    except Exception:
        raise HTTPException(status_code=400, detail="invalid json")

    message = payload.get("message")
    if not message:
        raise HTTPException(status_code=400, detail="missing message")

    data_b64 = message.get("data")
    decoded = {}
    raw = None
    if data_b64:
        try:
            raw = base64.b64decode(data_b64).decode("utf-8")
            decoded = json.loads(raw)
        except Exception:
            decoded = {"raw": raw or data_b64}

    # decode historyId and emailAddress if present
    history_id = None
    email_address = None
    if isinstance(decoded, dict):
        history_id = decoded.get("historyId")
        email_address = decoded.get("emailAddress") or decoded.get("email")

    attrs = message.get("attributes") or {}
    if not email_address:
        email_address = attrs.get("emailAddress") or attrs.get("email")

    db = SessionLocal()
    try:
        if email_address:
            integrations = db.query(Integration).filter(Integration.account_email == email_address, Integration.provider == "gmail").all()
        else:
            integrations = db.query(Integration).filter(Integration.provider == "gmail").all()

        if not integrations:
            logger.info("No integrations matched for email %s", email_address)

        for integ in integrations:
            try:
                # enqueue a background job to process history for this integration
                q.enqueue("gmail_client.process_history_for_integration", integ.id, history_id)
            except Exception:
                logger.exception("Failed to enqueue gmail history job for integration %s", integ.id)
    finally:
        db.close()

    return {"status": "accepted", "decoded": decoded}