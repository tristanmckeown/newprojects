from sqlalchemy import Column, Integer, String, DateTime, Text, JSON
from sqlalchemy.ext.declarative import declarative_base
from datetime import datetime

Base = declarative_base()

class Integration(Base):
    __tablename__ = "integrations"
    id = Column(Integer, primary_key=True, index=True)
    provider = Column(String, index=True)
    tenant_id = Column(String, index=True, nullable=True)
    account_email = Column(String, nullable=True)
    access_token = Column(Text, nullable=True)
    refresh_token = Column(Text, nullable=True)
    scope = Column(String, nullable=True)
    expires_at = Column(Integer, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

class Document(Base):
    __tablename__ = "documents"
    id = Column(Integer, primary_key=True, index=True)
    tenant_id = Column(String, index=True)
    original_filename = Column(String)
    s3_key = Column(String, index=True)
    content_type = Column(String)
    size = Column(Integer)
    received_at = Column(DateTime, default=datetime.utcnow)
    sender = Column(String)
    recipients = Column(String)
    client_id = Column(String, nullable=True)
    extracted_metadata = Column(JSON, nullable=True)
    processing_status = Column(String, default="pending")