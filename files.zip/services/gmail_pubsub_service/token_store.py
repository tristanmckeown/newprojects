import os, base64
from cryptography.fernet import Fernet, InvalidToken

KEY_ENV = "TOKEN_ENCRYPTION_KEY"

def _get_fernet():
    key = os.getenv(KEY_ENV)
    if not key:
        import hashlib
        secret = os.getenv("SECRET_KEY", "dev-secret-key")
        digest = hashlib.sha256(secret.encode()).digest()
        key = base64.urlsafe_b64encode(digest)
    return Fernet(key)

def encrypt_token(plaintext: str) -> str:
    if plaintext is None:
        return None
    return _get_fernet().encrypt(plaintext.encode()).decode()

def decrypt_token(ciphertext: str) -> str:
    if ciphertext is None:
        return None
    try:
        return _get_fernet().decrypt(ciphertext.encode()).decode()
    except InvalidToken:
        return None