```markdown
Summary
This PR adds two new microservices and supporting infrastructure to enable near-real-time ingestion of email attachments from Microsoft 365 and Gmail. It includes background workers, secure token storage (dev-mode Fernet with an envelope abstraction), admin endpoints, subscription renewal tooling, unit test stubs, and a CI workflow.

What’s included (high level)
- services/m365_subscription_service
  - Subscription management: create/delete Microsoft Graph subscriptions and map subscriptionId -> Integration
  - Delta handler: run_delta_for_subscription downloads attachments for changed messages and stores Document rows in the shared DB + uploads to MinIO
  - Token encryption helpers (token_store.py) — dev Fernet implementation; replace with KMS/Vault in production
  - Admin endpoints (list integrations/subscriptions, force-run delta, renew subscription, force-refresh tokens)
  - RQ worker skeletons: m365_worker.py and renew_worker.py
  - Tests: tests/test_m365_client.py (smoke test)
- services/gmail_pubsub_service
  - Pub/Sub push receiver (verifies OIDC JWT when present) and enqueues Gmail history processing
  - Direct Gmail history processing and attachment download (gmail_client.process_history_for_integration)
  - RQ worker for background processing (gmail_worker.py)
  - Token encryption (token_store.py) and admin endpoints (admin.py)
  - Tests: tests/test_gmail_client.py (smoke test)
- CI: .github/workflows/ci.yml runs pytest for the feature branch

How to test locally
1. Pull branch and install deps
   git fetch origin
   git checkout feature/m365-gmail-services
   # optionally create venv and install service requirements
   python -m venv .venv && source .venv/bin/activate
   pip install -r services/m365_subscription_service/requirements.txt
   pip install -r services/gmail_pubsub_service/requirements.txt
   pip install pytest

2. Set environment variables (example)
   DATABASE_URL=postgresql://docflow:docflowpass@db:5432/docflow
   REDIS_URL=redis://redis:6379/0
   MINIO_ENDPOINT=minio:9000
   MINIO_ACCESS_KEY=minioadmin
   MINIO_SECRET_KEY=minioadmin
   MINIO_BUCKET=docflow-dev
   MICROSOFT_CLIENT_ID=<your_microsoft_client_id>
   MICROSOFT_CLIENT_SECRET=<your_microsoft_client_secret>
   GOOGLE_CLIENT_ID=<your_google_client_id>
   GOOGLE_CLIENT_SECRET=<your_google_client_secret>
   TOKEN_ENCRYPTION_KEY=<base64-urlsafe-32-bytes>  # dev; use KMS in prod
   M365_NOTIFICATION_URL=https://<public>/services/m365_subscription_service/webhook/receive
   PUBSUB_AUDIENCE=<optional_pubsub_audience>

3. Run tests
   pytest -q

4. Run containers (example)
   docker-compose -f docker-compose.yml -f docker-compose.services.yml up --build

Security & production notes (must-read)
- Replace the Fernet dev fallback with KMS or Vault envelope encryption before production.
- Webhook endpoints MUST be public HTTPS. Use ngrok or a proper public endpoint for dev/testing.
- Validate clientState (per-subscription secret) for Microsoft Graph notifications.
- Validate Pub/Sub OIDC JWT (aud/iss) and use push OIDC config for Pub/Sub.
- Persist per-integration deltaLink/historyId to avoid reprocessing.
- Add retry/backoff/circuit-breakers for Graph/Gmail API calls, and monitoring/alerts for queue lengths and token expiry.

Checklist (done in this PR)
- [x] Add M365 subscription service and delta handler
- [x] Add Gmail Pub/Sub subscriber and history processor
- [x] Add RQ workers for background delta/history processing
- [x] Add token encryption abstraction and dev Fernet implementation
- [x] Add admin endpoints (list, renew, run-delta, refresh-token)
- [x] Add renew worker skeleton
- [x] Add smoke unit tests for critical flows
- [x] Add CI workflow (pytest) for branch

Remaining / recommended follow-up (post-merge)
- [ ] Integrate KMS/Vault for token encryption and rotate keys
- [ ] Persist and use deltaLink/historyId per integration for incremental syncs
- [ ] Add robust unit/integration tests with HTTP mocking of Graph/Gmail
- [ ] Harden webhook verification (clientState, JWT audience/issuer)
- [ ] Add monitoring, alerting, and operational runbooks
- [ ] Add license and CONTRIBUTING docs for the repo

Notes
- The branch feature/m365-gmail-services contains the changes and has CI configured. Please ensure required secrets (TOKEN_ENCRYPTION_KEY, provider credentials) are set in GitHub Actions secrets if you run CI with integration tests in future updates.

```